#!/usr/bin/perl

# getnfo 2.0

# Wheres my config file?
$config = "/glftpd/bin/getnfo.cfg";

### Opening configurations file
scalar eval `cat $config` or die "Cant open configuration file! ($config)\n";

### Using LWP module
use LWP::Simple;
require DBI;
require DBD::mysql;

### Finding time && setting tempvar
$time = scalar localtime(time);
$jsv = "a";

### SCRIPT
if (!$ARGV[0] or $ARGV[0] eq "-h") {
	print "getnfo 2.0 Copyright (C) 2002 pnG\n\n";
	print "usage:\n\n";
	print "getnfo -f \"moviename\"\n";
	print " This outputs information on moviename to the shell\n";
	print " example: getnfo -f \"The Matrix\"\n\n";
	print "getnfo -p\n";
	print " Makes getnfo scan $nfofile (specifyed in getnfo.cfg) and\n";
	print " post data into glftpd.log\n\n";
	print "getnfo -h\n";
	print " Prints this message\n\n";
} elsif ($ARGV[0] eq "-p") {
	## This is what I do if user wishes to 
	## read the datafile.
	print "Entering parse mode...\n";
	print "Parsing $nfofile...\n";
	## Parsing datafile
	&parse;
	## Checking if in a ignoredir
	if ($dupe) {die "Wont post $searchnumber because its in a ignored area ($dupe)\n";}
	if (!$searchnumber) {die "$nfofile is empty\n"};
	&readurl($searchnumber);

	## Checking for errors
	if ($error) {print "$error\n"} else {
		## This is what happens if no errors was found
		## Print to glftpd.log here.
		## Dont forget to do msg file aswell as mysql		
 
                ### Making business var
                if ($data{budget}) {$business .= "Budget was: $data{budget}"};
                if ($data{filmdates}) {$business .= ", the movie was filmed: $data{filmdates}"};
                if ($data{filmdates}) {$business .= ", and it was filmed in $data{filmlocation}"};
                if ($data{opendate}) {$business .= ". It opened on $data{opendate}"};
                if ($data{openscreens}) {$business .= ", and it was displayed on $data{openscreens}"};
                if ($data{openinc}) {$business .= ". The total income of the first night was $data{openinc}"};

                ### EXCHANING VARS
                $LOGFORMAT =~ s/\?title/$data{title}/g;
                $LOGFORMAT =~ s/\?url/$data{url}/g;
                $LOGFORMAT =~ s/\?plot/$data{plot}/g;
                $LOGFORMAT =~ s/\?genre/$data{genre}/g;
                $LOGFORMAT =~ s/\?name/$data{name}/g;
                $LOGFORMAT =~ s/\?rating/$data{rating}/g;
                $LOGFORMAT =~ s/\?business/$business/g;
		$LOGFORMAT =~ s/\?time/$time/g;

		### Printing to glftpd.log
		print "Found $data{title} and logging it to $PATH_TO_GLFTPD_LOG...\n";
	        open GLFTPDLOG, ">> $PATH_TO_GLFTPD_LOG" or die "Couldnt open GLFTPD.LOG";
        	print GLFTPDLOG "$LOGFORMAT\n";
	        close GLFTPDLOG;

		### Printing message file if user wishes so
		&domessg;			

		### Inserting into mySQL database
		&doSQL;

		### Making stat-directory
		&makeSTAT;
	}

} elsif ($ARGV[0] eq "-f" and $ARGV[1] ne "") {
	print "Scanning imdb for: $ARGV[1]\n";
	&readurl($ARGV[1]);

        if ($error) {print "$error\n"} else {
		
		### Making business var
		if ($data{budget}) {$business .= "Budget was: $data{budget}"};
		if ($data{filmdates}) {$business .= ", the movie was filmed: $data{filmdates}"};
		if ($data{filmdates}) {$business .= ", and it was filmed in $data{filmlocation}"};
		if ($data{opendate}) {$business .= ". It opened on $data{opendate}"};
		if ($data{openscreens}) {$business .= ", and it was displayed on $data{openscreens}"};
		if ($data{openinc}) {$business .= ". The total income of the first night was $data{openinc}"};

		### EXCHANING VARS
                $TRIGGERFORMAT =~ s/\?title/$data{title}/g;
                $TRIGGERFORMAT =~ s/\?url/$data{url}/g;
                $TRIGGERFORMAT =~ s/\?plot/$data{plot}/g;
                $TRIGGERFORMAT =~ s/\?genre/$data{genre}/g;
                $TRIGGERFORMAT =~ s/\?name/$data{name}/g;
                $TRIGGERFORMAT =~ s/\?rating/$data{rating}/g;
                $TRIGGERFORMAT =~ s/\?business/$business/g;
                print "$TRIGGERFORMAT\n";
		
		### Adding to mysqldatabase
		&doSQL;
        }

} elsif ($ARGV[0] eq "-f" and !$ARGV[1]) {
	print "You must supply a movie name to search for. Try getnfo -h.\n";
};


############
### Subs ###
#########################################
### Sub for truncation imdburllog.log ###
sub trunct 
{
        open NFO, "> $nfofile";
        print NFO "";
        close NFO;
};

##################################################
### Sub for parsing out url and path from file ################
### This sub returns $searchnumber, wich is the imdb number ###
### and $dupe wich indicates if a IGNOREDIR was found.	    ###
sub parse
{
	## Opening temporary storage file
        open NFO, "< $nfofile";
        @NFO = <NFO>;
        close NFO;

	## Truncating storagefile
        &trunct;

        foreach  $thing (@NFO) {
		## Splitting and cleaningup vars
                ($pathtorel, $imdburl) = split("OOOO", $thing);
                $imdburl =~ s/\^M//;
                $pathtorel =~ s/\"//g;
                $pathtorel =~ s/IMDB: //;
		## Checking if file is in a ignored area
		foreach $folder (@IGNOREDIRS) {
			if ($pathtorel =~ /\/$folder\//i) {$dupe = $folder;};
		};
		
		## Cleaning out imdbnumber
		$imdburl =~ /\?(\d*)$/;
		$searchnumber = $1;
        };

}

#####################################
### Sub for reading info from web ###
sub readurl 
{
	## Parsing out information from imdb number or 
	## Title that came with sub
	##
	## Im going to add that into a hash, %data
	## for later use.
	##
	$imdbident = $_[0];

	## Defining urls
        my $infourl = "http://us.imdb.com/Title?$imdbident";
	my $bussurl = "http://us.imdb.com/Business?$imdbident";

	## Now sucking webpage with LWP
	$container = get "$infourl";
	if (!$container) {die "Couldnt get data from imdb!\n"};
	## First of all we need to see that we found a movie
	## and not came to title search
	if ($container =~ /<TITLE>IMDb title search<\/TITLE>/) {
		## Here we found multiple hits. 
		## Need to show user what I found	
		$container =~ /<H2><A NAME=\"mov\">Movies<\/A><\/H2>\n(.*\n.*\n.*\n.*\n.*)/;
		if (!$1) {$error = "Couldnt find any matches on $imdbident\n"} else {
			$error = "Try searching on:\n";
			$search = $1;
			@search = split(/\n/, $search);
			foreach $thing (@search) {
				$thing =~ /Title\?(\d*)\">(.*)<\/A>/;
				$error .= "$2 (imdb#: $1), ";
			};
			$error =~ s/, $//;
		};

	## Now checking if the search was invalid
	} elsif ($container =~ /<TITLE>Invalid title or title code<\/TITLE>/) {
		$error = "No hits on $imdbident could be found on the imdb";

	## Else lets parse some data
	} else {	

	## Lets parse some data now
	##
	## Parsing out imdbnumber if search was text
	if ($imdbident !=~ /(\d*)/) {
		$container =~ /<BASE HREF=\"http:\/\/us\.imdb\.com\/Title\?(\d*)\">/;
		$imdbident = $1;
	};

	## Parsing out the title
        $container =~ /<TITLE>(.*)<\/TITLE>/;
        $data{title} = $1;
        $data{title} =~ s/\"//g;

        ## Parsing out "Directed by"
        $container =~ /Directed by<\/B><BR>\n <A HREF=\"\/Name\?(.*)\">/;
        $data{name} = $1;
        $data{name} =~ s/,\+/ /;
        ($n1, $n2) = split(" ", $data{name});
        $data{name} = "$n2 $n1";

        ## Genre
        $container =~ /\/Sections\/Genres\/(\w*)\//g;
        $data{genre} = $1;
	##if ($2 ne "") {$genre = "$1 / $2"} else {$genre = $1};

        ## Plot
        $container =~ /<B CLASS=\"ch\">Plot Outline: <\/B>(.*) <A HREF=\"\/Plot\?/;
        if ($1 eq $data{genre}) {$data{plot} = "Unavailable..."} else {$data{plot} = $1; $data{plot} =~ s/\"//g;};

        ## User Rating
        $container =~ /<\/A> <B>(\d*)\.(\d*)<\/B>\/10 \((\d*)/;
        if ($1 ne $data{plot} and $1 ne $data{genre}) {$data{rating} = "$1.$2 / 10 with $3$4 votes"; $rrating = $1} else {$data{rating} = "N/A"};

	### Business
	## Resetting container var
	$container = "";
        $jsv =~ /./;

	# Fetching webpage
	$container = get "$bussurl";
	if (!$container) {$data{business} = "Unavalible"} else {
		### Here Im Scanning Business Data
		## Budget
		$container =~ /<DL><DT><B>Budget<!-- BT --><\/B><\/DT>\n  <DD><DIV CLASS=botpad>(.*)<BR>\n/;
		if ($1) {$data{budget} = $1};

		$jsv =~ /./;

		## Filming dates
		$container =~ /<DT><B>Filming Dates<!-- SD --><\/B><\/DT>\n  <DD><DIV CLASS=botpad>(.*)<BR>\n/;
		if ($1) {$data{filmdates} = $1};
		if ($data{filmdates} =~ /HREF/) {delete $data{filmdates}};

		## Filming Studio Location
		$container =~ /<DT><B>Filming Studio Location<!-- ST --><\/B><\/DT>\n  <DD><DIV CLASS=botpad>(.*)<\/DIV><\/DD>\n/;
		if ($1) {$data{filmlocation} = $1};
		
		## Opening weekend
		$container =~ /<!-- OW --><\/B><\/DT>\n  <DD><DIV CLASS=botpad>(.*) \(<A HREF=\"(.*)\">(.*)<\/A> <A HREF=\"(.*)\">(\d*)<\/A>\) \((.*)\)<BR>\n/;
		if ($1) {$data{openinc} = $1};
		if ($3 and $5) {$data{opendate} = "$3 $5"};
		if ($6) {$data{openscreens} = $6};
		$data{openinc} =~ s/&pound\;/�/;
		$data{openscreens} =~ s/(\(|\))//g;
	}

	### Setting URL
	$data{url} = "http://us.imdb.com/Title?$imdbident";

	### Cleaning up
        while( my ($key, $value) = each(%data) ) {
		if (!$value) {delete $data{$key}};
        };
    }
}

##################################
### Sub for making messagefile ###
sub domessg {
        if ($APPENDIMDB == 1) {
        $pathtorel =~ s/ $//;
        $messagefile = $GLFTPDROOT.$pathtorel."/$THEMESSAGEFILE";
	print "Creating messagefile $messagefile\n";

	## Finding out permissions
	$perms = `ls -l $GLFTPDROOT$pathtorel/*.nfo`;
	@permissions = split(/ +/, $perms);

	if ($APPEND == 0) {
	        open MESSAGE, "> $messagefile" or die "Couldnt open $messagefile\n";
	} else {
		open MESSAGE, ">> $messagefile" or die "Couldnt open $messagefile\n";
	};

        open TEMPLATE, "< $TEMPLATE" or die "Couldnt open your template file! ($TEMPLATE)";
        @MESSAGE = <TEMPLATE>;
        close TEMPLATE;
        foreach (@MESSAGE) { s/\?title/$data{title}/g; };
        foreach (@MESSAGE) { s/\?url/$data{url}/g; };
        foreach (@MESSAGE) { s/\?plot/$data{plot}/g; };
        foreach (@MESSAGE) { s/\?genre/$data{genre}/g; };
        foreach (@MESSAGE) { s/\?name/$data{name}/g; };
        foreach (@MESSAGE) { s/\?rating/$data{rating}/g; };
        print MESSAGE "\n@MESSAGE";
        close MESSAGE;
	# This doesnt work
	# system("chmod 777 $messagefile;chown $permissions[2] $messagefile;chgrp $permissions[3] $messagefile");
        };
};

################################################
### Sub for inserting data into sql database ###
sub doSQL {
        if ($MYSQL == 1 or $MYSQL == 2) {
                $dbh = DBI->connect("DBI:mysql:$SQLSET[1]:$SQLSET[0]", $SQLSET[2], $SQLSET[3]) or die "Couldnt connect to mySQL database, please check config!\n";
                $dosql = "SELECT * FROM $SQLSET[4] WHERE TITLE = '$title'";
                $sth = $dbh->prepare($dosql);
                $sqldata = $sth->execute;
                while (@row=$sth->fetchrow_array) {
                        $check = $row[0];
                }
                if (!$check) {
                        $data{title} =~ s/\'/\"/g;
                        $data{name} =~ s/\'/\"/g;
                        $data{genre} =~ s/\'/\"/g;
                        $data{business} =~ s/\'/\"/g;
                        $data{rating} =~ s/\'/\"/g;
                        $data{url} =~ s/\'/\"/g;
                        $data{plot} =~ s/\'/\"/g;
                        $dosql = "INSERT INTO $SQLSET[4] VALUES('', '$data{title}', '$data{name}', '$data{genre}', '$data{business}', '$data{rating}', '$data{url}', '$data{plot}')";
                        $sth = $dbh->prepare($dosql);
                        $sqldata = $sth->execute;
                }
        }
};

### Sub for making stat directory
sub makeSTAT {
        if ($CREATESTATDIR == 1) {
        $pathtorel =~ s/ $//;
        $messagefile = $GLFTPDROOT.$pathtorel."/"."\[$SITENAME\] \- $data{genre} \- $data{rating} on IMDB \[$SITENAME\]";
	$messagefile =~ s/ \/ / of /g;
	$messagefile =~ s/ /\\ /g;
        print "Creating status-directory $messagefile\n";

	system("mkdir $messagefile");
	# Doesnt work
        # system("chmod 777 $messagefile;chown $permissions[2] $messagefile;chgrp $permissions[3] $messagefile");
        };
};
